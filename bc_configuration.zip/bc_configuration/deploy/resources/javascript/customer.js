/*
 Customer-specific JavaScript can be added to this file.
 If this file is non-empty at runtime, it will be added
 to the core HTML template after the all.js file.

 The software includes proprietary JavaScript APIs
 licensed by Guidewire. These APIs - which can be identified
 with the prefix "Ext." - may be used only by Guidewire.
 You are not permitted to use these APIs for any purpose,
 including JavaScript development.
 */