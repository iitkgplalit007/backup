Ext.define('Gw.override.Date', {
  override: 'Ext.Date',

  useStrict : true
});