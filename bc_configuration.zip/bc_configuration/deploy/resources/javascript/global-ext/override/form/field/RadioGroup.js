Ext.define('Gw.override.form.RadioGroup', {
  override: 'Ext.form.RadioGroup',

  formItemCls : 'g-radio-group'

});
